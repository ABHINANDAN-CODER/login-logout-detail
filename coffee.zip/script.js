function view_alert(){
      document.getElementById("alert-view").style.display="block";
      document.getElementById("alert-view").innerText="email already exist";
}

function view_alert2(){
      document.getElementById("alert-view").style.display="block";
      document.getElementById("alert-view").innerText="Invalid credentials !";
}

function alerts(){
      alert("User exist !");
}