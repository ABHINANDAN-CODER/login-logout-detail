<?php

$host ="localhost";
$username ="root";
$passw = "";
$dbname = "vps";
$db_name = "mysql:host=$host; dbname=".$dbname;

?>